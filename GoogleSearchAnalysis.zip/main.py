import pandas as pd
from pytrends.request import TrendReq
import matplotlib.pyplot as plt
import time

# Step 1: Connect to Google Trends
pytrends = TrendReq(hl='en-US', tz=360)

# Step 2: Build Payload
kw_list = ["Cloud Computing"]
pytrends.build_payload(kw_list, cat=0, timeframe='today 12-m')
time.sleep(5)

# Step 3: Interest Over Time
data_time = pytrends.interest_over_time()
data_time_sorted = data_time.sort_values(by="Cloud Computing", ascending=False).head(10)
data_time_sorted.to_csv("data/interest_over_time.csv")
print("[INFO] Interest Over Time:")
print(data_time_sorted)

# Step 4: Interest by Region
data_region = pytrends.interest_by_region()
data_region_sorted = data_region.sort_values(by="Cloud Computing", ascending=False).head(10)
data_region_sorted.to_csv("data/interest_by_region.csv")
print("[INFO] Interest by Region:")
print(data_region_sorted)

# Step 5: Visualization
plt.figure(figsize=(10, 5))
data_region_sorted.reset_index().plot(x='geoName', y='Cloud Computing', kind='bar', legend=False)
plt.title("Interest by Region for 'Cloud Computing'")
plt.ylabel("Interest")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("plots/interest_by_region.png")
plt.close()

# Step 6: Related Queries
try:
    pytrends.build_payload(kw_list=['Cloud Computing'])
    related_queries = pytrends.related_queries()
    with open("data/related_queries.txt", "w") as f:
        f.write(str(related_queries.values()))
    print("[INFO] Related queries saved.")
except (KeyError, IndexError):
    print("[WARNING] No related queries found for 'Cloud Computing'")

# Step 7: Keyword Suggestions
suggestions = pytrends.suggestions(keyword='Cloud Computing')
df_suggestions = pd.DataFrame(suggestions).drop(columns='mid')
df_suggestions.to_csv("data/keyword_suggestions.csv", index=False)
print("[INFO] Keyword suggestions saved.")