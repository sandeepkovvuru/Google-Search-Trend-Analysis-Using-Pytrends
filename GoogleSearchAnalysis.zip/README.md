# Google Search Analysis with Python

## 📌 Project Title
**Google Search Trend Analysis Using Pytrends**

## 🧠 Project Description
This project uses the `pytrends` library to fetch and analyze Google Trends data for the keyword **"Cloud Computing"**. The project:
- Retrieves interest over time
- Displays interest by region
- Shows related search queries
- Suggests related keywords
- Visualizes search interest in bar charts

## 📂 Project Dataset
No external datasets are needed. All data is fetched live from Google Trends using the Pytrends API.

## 💻 Project Code
- `main.py`: Main script to run the analysis.
- `plots/`: Contains visualization of region-based interest.
- `data/`: Contains CSV and TXT files for:
    - Interest over time
    - Interest by region
    - Related queries
    - Keyword suggestions

## 🚀 How to Run
1. Install dependencies:
```
pip install pytrends matplotlib pandas
```
2. Run the main script:
```
python main.py
```

Output will be saved in the `plots/` and `data/` directories.